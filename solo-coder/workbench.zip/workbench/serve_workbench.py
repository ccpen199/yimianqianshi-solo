#!/usr/bin/env python3
import base64
import json
import fnmatch
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.abspath(os.path.join(ROOT_DIR, '../..'))
STATE_FILE = os.path.join(PROJECT_DIR, 'data', 'generated', 'prompt_state.json')
PROMPTS_FILE = os.path.join(PROJECT_DIR, 'data', 'generated', 'generation_prompts.json')
TRAE_ROOT = '/Users/chen/Documents/trae_projects'
GITHUB_REPO_URL = 'git@github.com:ccpen199/Trae-solo.git'
GITHUB_REPO_DIR = os.path.join(TRAE_ROOT, 'Trae-solo')
SYNC_EXCLUDES = [
  '.git/',
  'node_modules/',
  '.next/',
  '.nuxt/',
  'dist/',
  'build/',
  'coverage/',
  '.cache/',
  '.turbo/',
  '.vite/',
  '.DS_Store',
  '*.log',
  '.env',
  '.env.*',
]
SYNC_EXCLUDED_DIR_NAMES = {'node_modules', '.next', '.nuxt', 'dist', 'build', 'coverage', '.cache', '.turbo', '.vite'}
SYNC_EXCLUDED_FILE_NAMES = {'.DS_Store'}
SYNC_EXCLUDED_FILE_PATTERNS = {'*.log', '.env', '.env.*'}
FEISHU_TASK_URL = 'https://bcnrsnl3m9wk.feishu.cn/app/P4E0bo0tPaPybqsgyStczUahnvc?pageId=pgem2PGjgvLT01Vh'
SCENE_PREFIX = {
  'shopping': 'g',
  'social': 's',
  'entertainment': 'yl',
  'travel': 'l',
  'game': 'yx',
  'health': 'jk',
  'home': 'jj',
  'news_weather': 'xw',
  'art_design': 'ys',
  'fun_leisure': 'qx',
  'local_projects': 'xm',
}
SCENE_NAME_ALIASES = {
  '购物': 'shopping',
  '社交': 'social',
  '娱乐': 'entertainment',
  '旅游': 'travel',
  '游戏': 'game',
  '健康': 'health',
  '家居': 'home',
  '新闻与天气': 'news_weather',
  '艺术与设计': 'art_design',
  '趣味休闲': 'fun_leisure',
  '本机项目': 'local_projects',
}


def read_json(path: str, fallback):
  try:
    with open(path, 'r', encoding='utf-8') as file:
      return json.load(file)
  except FileNotFoundError:
    return fallback


def write_json(path: str, payload):
  os.makedirs(os.path.dirname(path), exist_ok=True)
  tmp = f'{path}.tmp'
  with open(tmp, 'w', encoding='utf-8') as file:
    json.dump(payload, file, ensure_ascii=False, indent=2)
    file.write('\n')
  os.replace(tmp, path)


def safe_segment(value: str) -> str:
  value = str(value or '').strip()
  value = re.sub(r'[\\/:*?"<>|\s]+', '_', value)
  value = value.strip('._')
  return value or '未分类'


def scene_segment(value: str) -> str:
  key = str(value or '').strip()
  if key in SCENE_PREFIX:
    return key
  return SCENE_NAME_ALIASES.get(key, safe_segment(value))


def migrate_legacy_scene_dirs():
  for legacy, canonical in SCENE_NAME_ALIASES.items():
    legacy_dir = os.path.join(TRAE_ROOT, legacy)
    canonical_dir = os.path.join(TRAE_ROOT, canonical)
    if os.path.isdir(legacy_dir) and not os.path.exists(canonical_dir):
      os.rename(legacy_dir, canonical_dir)


def load_prompts():
  prompts = read_json(PROMPTS_FILE, [])
  return prompts if isinstance(prompts, list) else []


def default_order_token(prompt):
  scene = scene_segment(prompt.get('business_domain'))
  return f"{SCENE_PREFIX.get(scene, 'x')}-{prompt.get('global_order')}"


def normalize_order_token(prompt, order_value):
  scene = scene_segment(prompt.get('business_domain'))
  prefix = SCENE_PREFIX.get(scene, 'x')
  if order_value is None:
    return default_order_token(prompt)
  if isinstance(order_value, int):
    return f'{prefix}-{order_value}'

  text = str(order_value).strip()
  if not text:
    return default_order_token(prompt)
  if re.fullmatch(r'\d+', text):
    return f'{prefix}-{int(text)}'
  match = re.fullmatch(r'([A-Za-z]+)-(\d+)', text)
  if match:
    return f'{match.group(1).lower()}-{int(match.group(2))}'
  return text


def extract_order_number(order_value):
  text = str(order_value or '').strip()
  if re.fullmatch(r'\d+', text):
    return int(text)
  match = re.fullmatch(r'[A-Za-z]+-(\d+)', text)
  if match:
    return int(match.group(1))
  return None


def image_extension_from_mime(mime_type: str) -> str:
  normalized = str(mime_type or '').split(';', 1)[0].strip().lower()
  return {
    'image/png': '.png',
    'image/jpeg': '.jpg',
    'image/jpg': '.jpg',
    'image/webp': '.webp',
    'image/gif': '.gif',
    'image/svg+xml': '.svg',
  }.get(normalized, '.png')


def safe_image_filename(filename: str, mime_type: str) -> str:
  base = os.path.basename(str(filename or '').strip())
  base = re.sub(r'[\\/:*?"<>|\s]+', '_', base).strip('._')
  ext = os.path.splitext(base)[1].lower()
  allowed = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg'}
  if not base or ext not in allowed:
    base = f'map_{time.strftime("%Y%m%d_%H%M%S")}{image_extension_from_mime(mime_type)}'
  return base


def build_used_orders(state, current_prompt_id=None):
  prompts = load_prompts()
  overrides = state.get('orders', {}) if isinstance(state, dict) else {}
  used = {}
  for prompt in prompts:
    prompt_id = prompt.get('id')
    if prompt_id == current_prompt_id:
      continue
    order = normalize_order_token(prompt, overrides.get(prompt_id, default_order_token(prompt)))
    if order is not None:
      used[str(order)] = prompt_id
  return used


def ensure_prompt_folder(scene, order):
  scene_dir = os.path.join(TRAE_ROOT, scene_segment(scene))
  order_dir = os.path.join(scene_dir, str(order))
  os.makedirs(order_dir, exist_ok=True)
  return order_dir


def ensure_all_prompt_folders():
  prompts = load_prompts()
  state = read_json(STATE_FILE, {'completed': {}, 'orders': {}})
  orders = state.get('orders', {})
  count = 0
  for prompt in prompts:
    order = normalize_order_token(prompt, orders.get(prompt.get('id'), default_order_token(prompt)))
    if order is None:
      continue
    if str(order) == default_order_token(prompt):
      scene_dir = os.path.join(TRAE_ROOT, scene_segment(prompt.get('business_domain')))
      old_numeric = os.path.join(scene_dir, str(prompt.get('global_order')))
      new_prefixed = os.path.join(scene_dir, str(order))
      if os.path.isdir(old_numeric) and not os.path.exists(new_prefixed):
        os.rename(old_numeric, new_prefixed)
    ensure_prompt_folder(prompt.get('business_domain'), order)
    count += 1
  return count


def pick_folder(start_path: str) -> str:
  if sys.platform != 'darwin':
    raise RuntimeError('folder picker currently supports macOS only')

  prompt = '请选择项目仓库文件夹'
  start_path = (start_path or '').strip()
  script_lines = [f'set promptText to "{prompt}"']

  if start_path and os.path.isdir(start_path):
    safe_path = start_path.replace('"', '\\"')
    script_lines.append(f'set baseFolder to POSIX file "{safe_path}"')
    script_lines.append('set chosenFolder to choose folder with prompt promptText default location baseFolder')
  else:
    script_lines.append('set chosenFolder to choose folder with prompt promptText')

  script_lines.append('POSIX path of chosenFolder')
  cmd = ['osascript']
  for line in script_lines:
    cmd.extend(['-e', line])

  try:
    output = subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT).strip()
    return output
  except subprocess.CalledProcessError as err:
    msg = (err.output or '').strip()
    if 'User canceled' in msg:
      raise RuntimeError('user canceled')
    raise RuntimeError(msg or 'failed to pick folder')
  except FileNotFoundError:
    raise RuntimeError('osascript not found')


def run_cmd(cmd, cwd=None, check=True):
  completed = subprocess.run(
    cmd,
    cwd=cwd,
    text=True,
    capture_output=True,
    check=False,
  )
  if check and completed.returncode != 0:
    detail = completed.stderr.strip() or completed.stdout.strip() or 'command failed'
    raise RuntimeError(f"{' '.join(cmd)}: {detail}")
  return completed


def log_sync(message: str):
  print(f'[sync-github] {message}', flush=True)


def run_applescript(lines):
  cmd = ['osascript']
  for line in lines:
    cmd.extend(['-e', line])
  completed = subprocess.run(cmd, text=True, capture_output=True, check=False)
  if completed.returncode != 0:
    detail = completed.stderr.strip() or completed.stdout.strip() or 'AppleScript failed'
    raise RuntimeError(detail)
  return completed.stdout.strip()


def chrome_execute_js(script: str):
  js_literal = json.dumps(script, ensure_ascii=False)
  try:
    output = run_applescript([
      'tell application "Google Chrome"',
      'activate',
      'if (count of windows) is 0 then make new window',
      f'execute active tab of front window javascript {js_literal}',
      'end tell',
    ])
  except RuntimeError as err:
    message = str(err)
    if 'not allowed' in message.lower() or 'javascript' in message.lower():
      raise RuntimeError('Chrome 未允许 Apple Events 执行 JavaScript，请在 Chrome 菜单 View/开发者 中开启 “Allow JavaScript from Apple Events” 后重试')
    raise
  try:
    return json.loads(output) if output else {}
  except json.JSONDecodeError:
    return {'ok': False, 'raw': output}


def focus_feishu_task_tab():
  target_origin = 'bcnrsnl3m9wk.feishu.cn'
  target_app = 'P4E0bo0tPaPybqsgyStczUahnvc'
  url_literal = FEISHU_TASK_URL.replace('"', '\\"')
  origin_literal = target_origin.replace('"', '\\"')
  app_literal = target_app.replace('"', '\\"')
  run_applescript([
    'tell application "Google Chrome"',
    'activate',
    'if (count of windows) is 0 then make new window',
    f'set targetUrl to "{url_literal}"',
    f'set targetOrigin to "{origin_literal}"',
    f'set targetApp to "{app_literal}"',
    'set foundTab to false',
    'repeat with w in windows',
    'repeat with i from 1 to count of tabs of w',
    'set tabUrl to URL of tab i of w',
    'if tabUrl contains targetOrigin and tabUrl contains targetApp then',
    'set active tab index of w to i',
    'set index of w to 1',
    'set foundTab to true',
    'exit repeat',
    'end if',
    'end repeat',
    'if foundTab then exit repeat',
    'end repeat',
    'if not foundTab then set URL of active tab of front window to targetUrl',
    'end tell',
  ])


FEISHU_INIT_JS = r"""
(function () {
  function visible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 2 && rect.height > 2;
  }
  function text(el) {
    return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  }
  function clickElement(el) {
    const target = el.closest('button,[role="button"],[tabindex],a') || el;
    target.scrollIntoView({ block: 'center', inline: 'center' });
    const rect = target.getBoundingClientRect();
    const options = { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
    target.dispatchEvent(new MouseEvent('mousedown', options));
    target.dispatchEvent(new MouseEvent('mouseup', options));
    target.click();
  }
  function clickText(label) {
    const nodes = Array.from(document.querySelectorAll('button,[role="button"],span,div,a'));
    const matches = nodes
      .filter((el) => visible(el) && text(el).includes(label))
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return (ar.width * ar.height) - (br.width * br.height);
      });
    if (!matches.length) return false;
    clickElement(matches[0]);
    return true;
  }
  window.__feishuClaimBot = { rowIndex: 0, page: 1, selected: false, startedAt: Date.now() };
  const clickedTaskTab = clickText('领取任务');
  const clickedDetailList = clickText('详情列表');
  return JSON.stringify({ ok: true, clickedTaskTab, clickedDetailList });
})();
"""


FEISHU_SELECT_ROW_JS = r"""
(function () {
  const bot = window.__feishuClaimBot || (window.__feishuClaimBot = { rowIndex: 0, page: 1, selected: false });
  function visible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 2 && rect.height > 2;
  }
  function text(el) {
    return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  }
  function clickElement(el) {
    const target = el.closest('button,[role="button"],[tabindex],a') || el;
    target.scrollIntoView({ block: 'center', inline: 'center' });
    const rect = target.getBoundingClientRect();
    const options = { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
    target.dispatchEvent(new MouseEvent('mousedown', options));
    target.dispatchEvent(new MouseEvent('mouseup', options));
    target.click();
  }
  function rowsFromDetailList() {
    const activePane = document.querySelector('.tabs-widget-tab-pane-active') || document;
    const rows = Array.from(activePane.querySelectorAll('tr.list-table-row-detail[data-index]'))
      .filter((row) => visible(row))
      .sort((a, b) => Number(a.dataset.index || 0) - Number(b.dataset.index || 0));
    if (rows.length) return rows;
    return Array.from(activePane.querySelectorAll('.list-aggregated-item-cell[data-simple-tooltip-text]'))
      .filter((el) => visible(el) && /^\d{2,8}$/.test(text(el)))
      .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
  }
  function clickNextPage() {
    const nextText = String((bot.page || 1) + 1);
    const pageButton = Array.from(document.querySelectorAll('button,[role="button"],span,div'))
      .find((el) => visible(el) && text(el) === nextText && el.getBoundingClientRect().top > window.innerHeight * 0.65);
    if (pageButton) {
      clickElement(pageButton);
      bot.page = (bot.page || 1) + 1;
      bot.rowIndex = 0;
      return true;
    }
    const nextButton = Array.from(document.querySelectorAll('button,[role="button"],[aria-label],[title]'))
      .find((el) => {
        if (!visible(el)) return false;
        const label = `${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${text(el)}`.toLowerCase();
        return label.includes('下一') || label.includes('next');
      });
    if (nextButton) {
      clickElement(nextButton);
      bot.page = (bot.page || 1) + 1;
      bot.rowIndex = 0;
      return true;
    }
    return false;
  }
  const rows = rowsFromDetailList();
  if (bot.claimedLast && bot.lastUid) {
    const previousIndex = rows.findIndex((item) => {
      const value = item.querySelector?.('.list-aggregated-item-cell')?.textContent || text(item);
      return value.trim() === String(bot.lastUid).trim();
    });
    if (previousIndex >= 0) bot.rowIndex = previousIndex + 1;
    bot.claimedLast = false;
  }
  if (bot.rowIndex >= rows.length) {
    const pageTurned = clickNextPage();
    return JSON.stringify({ ok: pageTurned, action: 'page', pageTurned, rowCount: rows.length, page: bot.page || 1 });
  }
  const row = rows[bot.rowIndex];
  const uid = (row.querySelector?.('.list-aggregated-item-cell')?.textContent || text(row)).trim();
  clickElement(row.querySelector?.('.list-table-row-container') || row);
  bot.selected = true;
  bot.lastUid = uid;
  return JSON.stringify({ ok: true, action: 'select', rowIndex: bot.rowIndex, uid, rowCount: rows.length, page: bot.page || 1 });
})();
"""


FEISHU_CLAIM_BUTTON_JS = r"""
(function () {
  const bot = window.__feishuClaimBot || (window.__feishuClaimBot = { rowIndex: 0, page: 1, selected: false });
  function visible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 2 && rect.height > 2;
  }
  function text(el) {
    return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  }
  function clickElement(el) {
    const target = el.closest('button,[role="button"],[tabindex],a') || el;
    target.scrollIntoView({ block: 'center', inline: 'center' });
    const rect = target.getBoundingClientRect();
    const options = { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
    target.dispatchEvent(new MouseEvent('mousedown', options));
    target.dispatchEvent(new MouseEvent('mouseup', options));
    target.click();
  }
  const activePane = document.querySelector('.tabs-widget-tab-pane-active') || document;
  let buttons = Array.from(activePane.querySelectorAll('.bitable-card-edit-cell-editor-Button button'))
    .filter((el) => visible(el) && text(el).includes('领取题目'));
  if (!buttons.length) {
    buttons = Array.from(activePane.querySelectorAll('button'))
      .filter((el) => visible(el) && text(el).includes('领取题目'));
  }
  if (!buttons.length) {
    bot.rowIndex = (bot.rowIndex || 0) + 1;
    bot.selected = false;
    return JSON.stringify({ ok: false, action: 'claim', claimed: false, reason: '未找到领取题目按钮', rowIndex: bot.rowIndex });
  }
  clickElement(buttons[0]);
  bot.claimedLast = true;
  bot.selected = false;
  return JSON.stringify({ ok: true, action: 'claim', claimed: true, rowIndex: bot.rowIndex });
})();
"""


def claim_feishu_tasks(count: int):
  if sys.platform != 'darwin':
    raise RuntimeError('飞书领取自动化当前只支持 macOS + Google Chrome')
  if count <= 0 or count > 200:
    raise RuntimeError('领取数量必须在 1-200 之间')

  focus_feishu_task_tab()
  time.sleep(3.0)
  init_result = chrome_execute_js(FEISHU_INIT_JS)
  time.sleep(1.2)

  claimed = 0
  attempts = 0
  page_turns = 0
  events = []
  while claimed < count and attempts < count * 5:
    attempts += 1
    selected = chrome_execute_js(FEISHU_SELECT_ROW_JS)
    events.append(selected)
    if selected.get('action') == 'page':
      if selected.get('pageTurned'):
        page_turns += 1
        time.sleep(1.2)
        continue
      break
    if not selected.get('ok'):
      break
    time.sleep(0.65)
    result = chrome_execute_js(FEISHU_CLAIM_BUTTON_JS)
    events.append(result)
    if result.get('claimed'):
      claimed += 1
    time.sleep(0.9)

  return {
    'ok': True,
    'requested': count,
    'claimed': claimed,
    'attempts': attempts,
    'page_turns': page_turns,
    'init': init_result,
    'events': events[-12:],
  }


def sanitize_branch_name(value: str) -> str:
  text = str(value or '').strip().lower()
  text = re.sub(r'[^a-z0-9._/-]+', '-', text)
  text = re.sub(r'/+', '/', text).strip('/.-')
  return text or 'sync-unknown'


def folder_has_sync_content(path: str) -> bool:
  if not os.path.isdir(path):
    return False
  for root, dirs, files in os.walk(path):
    dirs[:] = [name for name in dirs if name != '.git']
    if files:
      return True
  return False


def ensure_github_repo():
  if not os.path.isdir(os.path.join(GITHUB_REPO_DIR, '.git')):
    parent = os.path.dirname(GITHUB_REPO_DIR)
    os.makedirs(parent, exist_ok=True)
    if os.path.exists(GITHUB_REPO_DIR):
      log_sync('repo cache is missing .git; rebuilding mirror directory')
      shutil.rmtree(GITHUB_REPO_DIR)
    run_cmd(['git', 'clone', GITHUB_REPO_URL, GITHUB_REPO_DIR], check=True)
  else:
    run_cmd(['git', 'remote', 'set-url', 'origin', GITHUB_REPO_URL], cwd=GITHUB_REPO_DIR, check=True)

  run_cmd(['git', 'fetch', '--all', '--prune'], cwd=GITHUB_REPO_DIR, check=True)

  user_name = run_cmd(['git', 'config', '--get', 'user.name'], cwd=GITHUB_REPO_DIR, check=False).stdout.strip()
  user_email = run_cmd(['git', 'config', '--get', 'user.email'], cwd=GITHUB_REPO_DIR, check=False).stdout.strip()
  if not user_name:
    run_cmd(['git', 'config', 'user.name', 'Trae Sync Bot'], cwd=GITHUB_REPO_DIR, check=True)
  if not user_email:
    run_cmd(['git', 'config', 'user.email', 'trae-sync-bot@local'], cwd=GITHUB_REPO_DIR, check=True)


def default_remote_branch():
  ref = run_cmd(
    ['git', 'symbolic-ref', '--short', 'refs/remotes/origin/HEAD'],
    cwd=GITHUB_REPO_DIR,
    check=False,
  ).stdout.strip()
  if ref.startswith('origin/'):
    return ref.split('/', 1)[1]
  return 'main'


def remote_branch_exists(branch: str) -> bool:
  out = run_cmd(['git', 'ls-remote', '--heads', 'origin', branch], cwd=GITHUB_REPO_DIR, check=True).stdout.strip()
  return bool(out)


def reset_github_worktree():
  # This directory is a generated mirror used only for GitHub sync.
  # Reset before each branch switch so a failed previous sync cannot poison the next one.
  run_cmd(['git', 'reset', '--hard'], cwd=GITHUB_REPO_DIR, check=True)
  run_cmd(['git', 'clean', '-fdx'], cwd=GITHUB_REPO_DIR, check=True)


def remove_sync_excluded_artifacts(path: str):
  for root, dirs, files in os.walk(path, topdown=True):
    dirs[:] = [name for name in dirs if name != '.git']
    for name in list(dirs):
      if name in SYNC_EXCLUDED_DIR_NAMES:
        shutil.rmtree(os.path.join(root, name), ignore_errors=True)
        dirs.remove(name)
    for name in files:
      if name in SYNC_EXCLUDED_FILE_NAMES or any(fnmatch.fnmatch(name, pattern) for pattern in SYNC_EXCLUDED_FILE_PATTERNS):
        try:
          os.remove(os.path.join(root, name))
        except FileNotFoundError:
          pass


def sync_one_completed_prompt(prompt: dict, order_token: str, base_branch: str):
  prompt_id = str(prompt.get('id') or '').strip()
  scene = scene_segment(prompt.get('business_domain'))
  source_dir = os.path.join(TRAE_ROOT, scene, str(order_token))
  if not folder_has_sync_content(source_dir):
    return {'prompt_id': prompt_id, 'order': str(order_token), 'status': 'skipped', 'reason': 'source folder is empty'}

  branch = sanitize_branch_name(str(order_token))
  existed = remote_branch_exists(branch)
  reset_github_worktree()
  log_sync(f'{order_token}: checkout {branch}')
  if existed:
    run_cmd(['git', 'checkout', '-B', branch, f'origin/{branch}'], cwd=GITHUB_REPO_DIR, check=True)
  else:
    run_cmd(['git', 'checkout', '-B', branch, f'origin/{base_branch}'], cwd=GITHUB_REPO_DIR, check=True)
  run_cmd(['git', 'branch', '--unset-upstream'], cwd=GITHUB_REPO_DIR, check=False)

  # Keep branch content in sync with the local project folder.
  rsync_cmd = ['rsync', '-a', '--delete']
  for pattern in SYNC_EXCLUDES:
    rsync_cmd.append(f'--exclude={pattern}')
  rsync_cmd.extend([f'{source_dir}/', f'{GITHUB_REPO_DIR}/'])
  log_sync(f'{order_token}: copy files')
  run_cmd(rsync_cmd, check=True)
  remove_sync_excluded_artifacts(GITHUB_REPO_DIR)

  changed = run_cmd(['git', 'status', '--porcelain'], cwd=GITHUB_REPO_DIR, check=True).stdout.strip()
  commit_created = False
  if changed:
    log_sync(f'{order_token}: commit changes')
    run_cmd(['git', 'add', '-A'], cwd=GITHUB_REPO_DIR, check=True)
    run_cmd(['git', 'commit', '-m', f'sync: {branch} ({prompt_id})'], cwd=GITHUB_REPO_DIR, check=True)
    commit_created = True

  log_sync(f'{order_token}: push {branch}')
  if existed:
    run_cmd(['git', 'push', '--force', 'origin', f'HEAD:refs/heads/{branch}'], cwd=GITHUB_REPO_DIR, check=True)
    action = 'force-synced'
  else:
    run_cmd(['git', 'push', '-u', 'origin', branch], cwd=GITHUB_REPO_DIR, check=True)
    action = 'created-and-synced'

  result = {
    'prompt_id': prompt_id,
    'order': str(order_token),
    'branch': branch,
    'status': 'synced',
    'action': action,
    'synced_before': existed,
    'commit_created': commit_created,
  }
  if not commit_created:
    result['reason'] = 'no file changes'
  return result


def sync_all_completed_to_github():
  log_sync('start')
  ensure_github_repo()
  base_branch = default_remote_branch()

  prompts = load_prompts()
  state = read_json(STATE_FILE, {'completed': {}, 'orders': {}})
  completed_map = state.get('completed', {}) if isinstance(state, dict) else {}
  order_map = state.get('orders', {}) if isinstance(state, dict) else {}

  completed_ids = {
    pid for pid, info in completed_map.items()
    if isinstance(info, dict) and info.get('completed')
  }

  prompt_by_id = {str(prompt.get('id')): prompt for prompt in prompts}
  target_ids = [pid for pid in completed_ids if pid in prompt_by_id]
  target_ids.sort()

  results = []
  for index, prompt_id in enumerate(target_ids, start=1):
    prompt = prompt_by_id[prompt_id]
    order_token = normalize_order_token(prompt, order_map.get(prompt_id, default_order_token(prompt)))
    log_sync(f'{index}/{len(target_ids)} {order_token}')
    if order_token in (None, ''):
      results.append({'prompt_id': prompt_id, 'status': 'skipped', 'reason': 'missing order token'})
      continue
    try:
      result = sync_one_completed_prompt(prompt, str(order_token), base_branch)
      results.append(result)
    except Exception as err:
      results.append({
        'prompt_id': prompt_id,
        'order': str(order_token),
        'status': 'failed',
        'reason': str(err),
      })
      log_sync(f'{order_token}: failed: {err}')

  synced = sum(1 for item in results if item.get('status') == 'synced')
  skipped = sum(1 for item in results if item.get('status') == 'skipped')
  failed = sum(1 for item in results if item.get('status') == 'failed')
  payload = {
    'ok': True,
    'repo': GITHUB_REPO_URL,
    'repo_dir': GITHUB_REPO_DIR,
    'base_branch': base_branch,
    'completed_total': len(target_ids),
    'synced': synced,
    'skipped': skipped,
    'failed': failed,
    'results': results,
  }
  log_sync(f'done synced={synced} skipped={skipped} failed={failed}')
  return payload


class Handler(SimpleHTTPRequestHandler):
  def _json(self, status: int, payload: dict):
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    self.send_response(status)
    self.send_header('Content-Type', 'application/json; charset=utf-8')
    self.send_header('Content-Length', str(len(body)))
    self.end_headers()
    self.wfile.write(body)

  def _read_json_body(self):
    length = int(self.headers.get('Content-Length', '0') or '0')
    if length <= 0:
      return {}
    return json.loads(self.rfile.read(length).decode('utf-8') or '{}')

  def do_GET(self):
    parsed = urlparse(self.path)
    if parsed.path == '/api/select-folder':
      query = parse_qs(parsed.query)
      start = (query.get('start') or [''])[0]
      try:
        path = pick_folder(start)
      except Exception as err:
        msg = str(err) or 'failed to pick folder'
        if msg == 'user canceled':
          self._json(499, {'ok': False, 'error': 'user canceled'})
        else:
          self._json(500, {'ok': False, 'error': msg})
        return
      self._json(200, {'ok': True, 'path': path})
      return

    if parsed.path == '/api/health':
      self._json(200, {'ok': True})
      return

    if parsed.path == '/api/prompt-state':
      state = read_json(STATE_FILE, {'completed': {}, 'orders': {}})
      state.setdefault('completed', {})
      state.setdefault('orders', {})
      self._json(200, {'ok': True, 'state': state})
      return

    return super().do_GET()

  def do_POST(self):
    parsed = urlparse(self.path)
    if parsed.path == '/api/prompt-state':
      try:
        payload = self._read_json_body()
        prompt_id = str(payload.get('prompt_id') or '').strip()
        completed = bool(payload.get('completed'))
        if not prompt_id:
          self._json(400, {'ok': False, 'error': 'prompt_id is required'})
          return
        state = read_json(STATE_FILE, {'completed': {}, 'orders': {}})
        state.setdefault('completed', {})
        state.setdefault('orders', {})
        if completed:
          state['completed'][prompt_id] = {'completed': True}
        else:
          state['completed'].pop(prompt_id, None)
        write_json(STATE_FILE, state)
        self._json(200, {'ok': True, 'state': state})
      except Exception as err:
        self._json(500, {'ok': False, 'error': str(err)})
      return

    if parsed.path == '/api/prompt-order':
      try:
        payload = self._read_json_body()
        prompt_id = str(payload.get('prompt_id') or '').strip()
        if not prompt_id:
          self._json(400, {'ok': False, 'error': 'prompt_id is required'})
          return
        prompts = load_prompts()
        prompt = next((item for item in prompts if item.get('id') == prompt_id), None)
        if not prompt:
          self._json(404, {'ok': False, 'error': 'prompt not found'})
          return
        raw_order = payload.get('order_token', payload.get('order'))
        order_token = normalize_order_token(prompt, raw_order)
        order_number = extract_order_number(order_token)
        if not order_number or order_number <= 0:
          self._json(400, {'ok': False, 'error': 'order must be a positive number or token'})
          return
        state = read_json(STATE_FILE, {'completed': {}, 'orders': {}})
        state.setdefault('completed', {})
        state.setdefault('orders', {})
        used = build_used_orders(state, current_prompt_id=prompt_id)
        if str(order_token) in used:
          self._json(409, {'ok': False, 'error': f'序号 {order_token} 已被占用'})
          return
        default_order = default_order_token(prompt)
        old_order = normalize_order_token(prompt, state.get('orders', {}).get(prompt_id, default_order))
        scene = prompt.get('business_domain')
        scene_dir = os.path.join(TRAE_ROOT, scene_segment(scene))
        old_folder = os.path.join(scene_dir, str(old_order)) if old_order else ''
        new_folder = os.path.join(scene_dir, str(order_token))

        if str(old_order) != str(order_token) and old_folder and os.path.isdir(old_folder) and not os.path.exists(new_folder):
          os.rename(old_folder, new_folder)
        else:
          os.makedirs(new_folder, exist_ok=True)

        if str(order_token) == str(default_order):
          state['orders'].pop(prompt_id, None)
        else:
          state['orders'][prompt_id] = order_token
        write_json(STATE_FILE, state)
        self._json(200, {'ok': True, 'state': state, 'folder': new_folder, 'old_order': old_order, 'order': order_number, 'order_token': order_token})
      except ValueError:
        self._json(400, {'ok': False, 'error': 'order must be a number'})
      except Exception as err:
        self._json(500, {'ok': False, 'error': str(err)})
      return

    if parsed.path == '/api/sync-folders':
      try:
        count = ensure_all_prompt_folders()
        self._json(200, {'ok': True, 'count': count, 'root': TRAE_ROOT})
      except Exception as err:
        self._json(500, {'ok': False, 'error': str(err)})
      return

    if parsed.path == '/api/sync-github-all':
      try:
        payload = sync_all_completed_to_github()
        self._json(200, payload)
      except Exception as err:
        traceback.print_exc()
        self._json(500, {'ok': False, 'error': str(err)})
      return

    if parsed.path == '/api/claim-feishu-tasks':
      try:
        payload = self._read_json_body()
        count = int(payload.get('count') or 0)
        result = claim_feishu_tasks(count)
        self._json(200, result)
      except ValueError:
        self._json(400, {'ok': False, 'error': 'count must be a positive integer'})
      except Exception as err:
        self._json(500, {'ok': False, 'error': str(err)})
      return

    if parsed.path == '/api/project-map-image':
      try:
        payload = self._read_json_body()
        scene = str(payload.get('scene') or '').strip()
        order = str(payload.get('order') or '').strip()
        data_url = str(payload.get('data_url') or '').strip()
        filename = str(payload.get('filename') or '').strip()
        if not scene or not order or not data_url:
          self._json(400, {'ok': False, 'error': 'scene, order and data_url are required'})
          return
        match = re.fullmatch(r'data:([^;,]+(?:;[^,]+)?);base64,(.+)', data_url, re.DOTALL)
        if not match:
          self._json(400, {'ok': False, 'error': 'image data must be a base64 data URL'})
          return
        mime_type = match.group(1).split(';', 1)[0]
        if not mime_type.startswith('image/'):
          self._json(400, {'ok': False, 'error': 'only image data is allowed'})
          return
        image_bytes = base64.b64decode(match.group(2), validate=True)
        if len(image_bytes) > 30 * 1024 * 1024:
          self._json(413, {'ok': False, 'error': 'image is too large'})
          return
        project_dir = os.path.join(TRAE_ROOT, scene_segment(scene), order)
        os.makedirs(project_dir, exist_ok=True)
        maps_dir = os.path.join(project_dir, 'maps')
        os.makedirs(maps_dir, exist_ok=True)
        safe_name = safe_image_filename(filename, mime_type)
        target_path = os.path.join(maps_dir, safe_name)
        if os.path.exists(target_path):
          stem, ext = os.path.splitext(safe_name)
          target_path = os.path.join(maps_dir, f'{stem}_{int(time.time())}{ext or image_extension_from_mime(mime_type)}')
        with open(target_path, 'wb') as file:
          file.write(image_bytes)
        self._json(200, {'ok': True, 'path': target_path, 'folder': maps_dir, 'filename': os.path.basename(target_path)})
      except Exception as err:
        self._json(500, {'ok': False, 'error': str(err)})
      return

    if parsed.path == '/api/open-project-folder':
      try:
        payload = self._read_json_body()
        scene = str(payload.get('scene') or '').strip()
        order = str(payload.get('order') or '').strip()
        if not scene or not order:
          self._json(400, {'ok': False, 'error': 'scene and order are required'})
          return
        folder_path = os.path.join(TRAE_ROOT, scene_segment(scene), order)
        if not os.path.isdir(folder_path):
          self._json(404, {'ok': False, 'error': f'folder not found: {folder_path}'})
          return
        trae_app = '/Applications/Trae CN.app'
        if os.path.exists(trae_app):
          run_cmd(['open', '-a', trae_app, folder_path], check=True)
        else:
          run_cmd(['open', folder_path], check=True)
        self._json(200, {'ok': True, 'folder': folder_path})
      except Exception as err:
        self._json(500, {'ok': False, 'error': str(err)})
      return

    if parsed.path == '/api/open-project-maps-folder':
      try:
        payload = self._read_json_body()
        scene = str(payload.get('scene') or '').strip()
        order = str(payload.get('order') or '').strip()
        if not scene or not order:
          self._json(400, {'ok': False, 'error': 'scene and order are required'})
          return
        maps_path = os.path.join(TRAE_ROOT, scene_segment(scene), order, 'maps')
        os.makedirs(maps_path, exist_ok=True)
        run_cmd(['open', maps_path], check=True)
        self._json(200, {'ok': True, 'folder': maps_path})
      except Exception as err:
        self._json(500, {'ok': False, 'error': str(err)})
      return

    self._json(404, {'ok': False, 'error': 'not found'})


def main():
  port = 8090
  if len(sys.argv) > 1:
    port = int(sys.argv[1])
  host = '127.0.0.1'
  if len(sys.argv) > 2:
    host = str(sys.argv[2] or host)

  os.chdir(ROOT_DIR)
  migrate_legacy_scene_dirs()
  ensure_all_prompt_folders()
  server = ThreadingHTTPServer((host, port), Handler)
  print(f'Workbench API+UI server started at http://{host}:{port}/index.html')
  try:
    server.serve_forever()
  except KeyboardInterrupt:
    pass
  finally:
    server.server_close()


if __name__ == '__main__':
  main()
