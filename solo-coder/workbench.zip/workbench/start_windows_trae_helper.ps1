$ErrorActionPreference = "Stop"

$TraeExe = if ($env:TRAE_EXE) { $env:TRAE_EXE } else { "D:\Users\Lenovo\AppData\Local\Programs\Trae CN\Trae CN.exe" }
$ProjectsRoot = if ($env:TRAE_PROJECTS_ROOT) { $env:TRAE_PROJECTS_ROOT } else { "D:\Users\Lenovo\Documents\trae_projects" }
$LocalProjectsRoot = if ($env:TRAE_LOCAL_PROJECTS_ROOT) { $env:TRAE_LOCAL_PROJECTS_ROOT } else { "" }
$Port = if ($env:TRAE_HELPER_PORT) { [int]$env:TRAE_HELPER_PORT } else { 8787 }

function Send-Json($Context, [int]$StatusCode, $Payload) {
  $Body = [System.Text.Encoding]::UTF8.GetBytes(($Payload | ConvertTo-Json -Compress))
  $Context.Response.StatusCode = $StatusCode
  $Context.Response.Headers.Add("Access-Control-Allow-Origin", "*")
  $Context.Response.Headers.Add("Access-Control-Allow-Methods", "POST, OPTIONS")
  $Context.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type")
  $Context.Response.ContentType = "application/json; charset=utf-8"
  $Context.Response.ContentLength64 = $Body.Length
  $Context.Response.OutputStream.Write($Body, 0, $Body.Length)
  $Context.Response.OutputStream.Close()
}

function Safe-Segment([string]$Value) {
  $Clean = ($Value.Trim() -replace "[\\/]", "")
  if ($Clean) { return $Clean }
  return "local_projects"
}

function Resolve-ProjectFolder([string]$Scene, [string]$Order) {
  $CleanScene = Safe-Segment $Scene
  $CleanOrder = (($Order.Trim()) -replace "[\\/]", "")
  if (-not $CleanOrder) { throw "order is required" }
  if ($CleanScene -eq "local_projects" -and $LocalProjectsRoot) {
    return Join-Path $LocalProjectsRoot $CleanOrder
  }
  return Join-Path (Join-Path $ProjectsRoot $CleanScene) $CleanOrder
}

$Listener = [System.Net.HttpListener]::new()
$Prefix = "http://127.0.0.1:$Port/"
$Listener.Prefixes.Add($Prefix)
$Listener.Start()

Write-Host "Windows Trae helper started at $Prefix"
Write-Host "TRAE_EXE=$TraeExe"
Write-Host "TRAE_PROJECTS_ROOT=$ProjectsRoot"
if ($LocalProjectsRoot) { Write-Host "TRAE_LOCAL_PROJECTS_ROOT=$LocalProjectsRoot" }

while ($Listener.IsListening) {
  $Context = $Listener.GetContext()
  try {
    if ($Context.Request.HttpMethod -eq "OPTIONS") {
      Send-Json $Context 200 @{ ok = $true }
      continue
    }
    if ($Context.Request.HttpMethod -ne "POST" -or $Context.Request.Url.AbsolutePath -ne "/open-trae") {
      Send-Json $Context 404 @{ ok = $false; error = "not found" }
      continue
    }

    $Reader = [System.IO.StreamReader]::new($Context.Request.InputStream, [System.Text.Encoding]::UTF8)
    $Payload = $Reader.ReadToEnd() | ConvertFrom-Json
    $Folder = Resolve-ProjectFolder $Payload.scene $Payload.order

    if (-not (Test-Path $TraeExe -PathType Leaf)) {
      Send-Json $Context 500 @{ ok = $false; error = "Trae not found: $TraeExe" }
      continue
    }
    if (-not (Test-Path $Folder -PathType Container)) {
      Send-Json $Context 404 @{ ok = $false; error = "project folder not found: $Folder" }
      continue
    }

    Start-Process -FilePath $TraeExe -ArgumentList "`"$Folder`""
    Send-Json $Context 200 @{ ok = $true; folder = $Folder; trae = $TraeExe }
  } catch {
    Send-Json $Context 500 @{ ok = $false; error = $_.Exception.Message }
  }
}
