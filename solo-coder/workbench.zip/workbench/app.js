const rowsEl = document.getElementById('projectRows');
const detailPanel = document.getElementById('detailPanel');
const promptBackground = document.getElementById('promptBackground');
const promptFeatures = document.getElementById('promptFeatures');
const promptDelivery = document.getElementById('promptDelivery');
const statsBar = document.getElementById('statsBar');
const domainFilter = document.getElementById('domainFilter');
const userFilter = document.getElementById('userFilter');
const platformFilter = document.getElementById('platformFilter');
const scenarioFilter = document.getElementById('scenarioFilter');
const searchInput = document.getElementById('searchInput');
const sceneButtons = document.getElementById('sceneButtons');
const syncGithubAllButton = document.getElementById('syncGithubAll');
const syncGithubStatus = document.getElementById('syncGithubStatus');
const feishuClaimCountInput = document.getElementById('feishuClaimCount');
const claimFeishuTasksButton = document.getElementById('claimFeishuTasks');
const claimFeishuStatus = document.getElementById('claimFeishuStatus');

let candidates = [];
let prompts = [];
let atoms = [];
let promptState = { completed: {} };
let filteredPrompts = [];
let selectedPromptId = '';
let selectedParts = { background: '', features: '', delivery: '' };
const scenePrefix = {
  shopping: 'g',
  social: 's',
  entertainment: 'yl',
  travel: 'l',
  game: 'yx',
  health: 'jk',
  home: 'jj',
  news_weather: 'xw',
  art_design: 'ys',
  fun_leisure: 'qx',
  local_projects: 'xm',
};

const domainAliases = {
  '购物': 'shopping',
  '社交': 'social',
  '娱乐': 'entertainment',
  '旅游': 'travel',
  '游戏': 'game',
  '健康': 'health',
  '家居': 'home',
  '新闻与天气': 'news_weather',
  '艺术与设计': 'art_design',
  '趣味休闲': 'fun_leisure',
  '本机项目': 'local_projects',
};

const domainDisplayNames = {
  shopping: '购物',
  social: '社交',
  entertainment: '娱乐',
  travel: '旅游',
  game: '游戏',
  health: '健康',
  home: '家居',
  news_weather: '新闻与天气',
  art_design: '艺术与设计',
  fun_leisure: '趣味休闲',
  local_projects: '本机项目',
};

function normalizeDomainName(domain) {
  return domainAliases[domain] || domain || '';
}

function displayDomainName(domain) {
  const normalized = normalizeDomainName(domain);
  return domainDisplayNames[normalized] || domain || '';
}

function cell(text, className = '') {
  const td = document.createElement('td');
  td.textContent = text ?? '';
  if (className) td.className = className;
  return td;
}

function shortList(items, limit = 3) {
  if (!Array.isArray(items)) return '';
  const head = items.slice(0, limit).join(' / ');
  return items.length > limit ? `${head} / +${items.length - limit}` : head;
}

function isCompleted(promptId) {
  return Boolean(promptState.completed?.[promptId]);
}

function orderPrefix(prompt) {
  const domain = normalizeDomainName(prompt.business_domain);
  return scenePrefix[domain] || 'x';
}

function orderToken(prompt, value) {
  const prefix = orderPrefix(prompt);
  if (typeof value === 'number' && Number.isInteger(value) && value > 0) {
    return `${prefix}-${value}`;
  }
  const text = String(value ?? '').trim();
  if (!text) return `${prefix}-${prompt.global_order}`;
  if (/^\d+$/.test(text)) return `${prefix}-${Number.parseInt(text, 10)}`;
  const match = text.match(/^([a-zA-Z]+)-(\d+)$/);
  if (match) return `${match[1].toLowerCase()}-${Number.parseInt(match[2], 10)}`;
  return text;
}

function orderNumber(value) {
  const text = String(value ?? '').trim();
  if (/^\d+$/.test(text)) return Number.parseInt(text, 10);
  const match = text.match(/-(\d+)$/);
  if (match) return Number.parseInt(match[1], 10);
  return Number.NaN;
}

function getOrder(prompt) {
  const raw = promptState.orders?.[prompt.id];
  return orderToken(prompt, raw || `${orderPrefix(prompt)}-${prompt.global_order}`);
}

function downloadText(filename, content) {
  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

async function copyText(text, button) {
  await navigator.clipboard.writeText(text);
  const original = button.textContent;
  button.textContent = '已复制';
  button.classList.add('copied');
  setTimeout(() => {
    button.textContent = original;
    button.classList.remove('copied');
  }, 1000);
}

function splitPrompt(prompt) {
  const parts = String(prompt || '').split(/\n\s*\n/).map((part) => part.trim()).filter(Boolean);
  if (parts.length <= 1) return { background: prompt || '', features: '', delivery: '' };
  if (parts.length === 2) return { background: parts[0], features: parts[1], delivery: '' };
  return { background: parts[0], features: parts.slice(1, -1).join('\n\n'), delivery: parts[parts.length - 1] };
}

function uniqueSorted(values) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b, 'zh-CN'));
}

function fillSelect(select, values, label, formatValue = (value) => value) {
  select.innerHTML = '';
  const all = document.createElement('option');
  all.value = '';
  all.textContent = `全部${label}`;
  select.appendChild(all);
  for (const value of values) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = formatValue(value);
    select.appendChild(option);
  }
}

function renderStats() {
  const candidateCount = new Set(prompts.map((prompt) => prompt.candidate_id)).size;
  const completedCount = Object.keys(promptState.completed || {}).length;
  const cards = [
    ['素材', atoms.length],
    ['方案', candidateCount],
    ['Prompt', prompts.length],
    ['完成', completedCount],
    ['当前筛选', filteredPrompts.length],
  ];
  statsBar.innerHTML = cards.map(([label, value]) => `<article class="${label === '完成' ? 'done-stat' : ''}"><b>${value}</b><span>${label}</span></article>`).join('');
}

function matchesSearch(prompt, keyword) {
  if (!keyword) return true;
  const haystack = [
    prompt.name,
    prompt.target_user,
    prompt.product_form,
    prompt.scenario,
    prompt.business_domain,
    prompt.monetization,
    prompt.prompt_persona,
    prompt.prompt_subtone,
    prompt.prompt_intent,
    prompt.prompt_detail,
    ...(prompt.capability_bundle || []),
  ].join(' ').toLowerCase();
  return haystack.includes(keyword.toLowerCase());
}

function applyFilters() {
  const domain = domainFilter.value;
  const user = userFilter.value;
  const platform = platformFilter.value;
  const scenario = scenarioFilter.value;
  const keyword = searchInput.value.trim();

  filteredPrompts = prompts.filter((prompt) => {
    if (domain && prompt.business_domain !== domain) return false;
    if (user && prompt.target_user !== user) return false;
    if (platform && prompt.product_form !== platform) return false;
    if (scenario && prompt.scenario !== scenario) return false;
    return matchesSearch(prompt, keyword);
  });

  renderStats();
  renderSceneButtons();
  renderRows();
  if (filteredPrompts.length && !filteredPrompts.some((prompt) => prompt.id === selectedPromptId)) {
    selectPrompt(filteredPrompts[0].id);
  } else if (!filteredPrompts.length) {
    selectedPromptId = '';
    detailPanel.hidden = true;
  }
}

function actionButton(label, className) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = className;
  button.textContent = label;
  return button;
}

async function setCompleted(promptId, completed) {
  const response = await fetch('/api/prompt-state', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt_id: promptId, completed }),
  });
  const payload = await response.json();
  if (!payload.ok) throw new Error(payload.error || '状态保存失败');
  promptState = payload.state || { completed: {} };
  renderStats();
  renderSceneButtons();
  renderRows();
}


async function savePromptOrder(row, order, input) {
  if (!Number.isInteger(order) || order <= 0) {
    input.classList.add('invalid-order');
    return false;
  }
  const nextToken = orderToken(row, order);
  const duplicate = prompts.find((item) => item.id !== row.id && orderToken(item, getOrder(item)) === nextToken);
  if (duplicate) {
    input.classList.add('invalid-order');
    return false;
  }
  const response = await fetch('/api/prompt-order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt_id: row.id, order, order_token: nextToken }),
  });
  const payload = await response.json();
  if (!payload.ok) {
    input.classList.add('invalid-order');
    return false;
  }
  promptState = payload.state || promptState;
  renderStats();
  renderSceneButtons();
  renderRows();
  return true;
}

function beginOrderEdit(row, orderTd) {
  const current = getOrder(row);
  const currentNumber = orderNumber(current);
  orderTd.innerHTML = '';
  orderTd.classList.add('editing');
  const input = document.createElement('input');
  input.className = 'order-input';
  input.type = 'number';
  input.min = '1';
  input.step = '1';
  input.value = Number.isInteger(currentNumber) && currentNumber > 0 ? String(currentNumber) : String(row.global_order || 1);
  orderTd.appendChild(input);
  input.focus();
  input.select();

  let finished = false;
  const finish = async (save) => {
    if (finished) return;
    finished = true;
    if (!save) {
      renderRows();
      return;
    }
    const next = Number.parseInt(input.value, 10);
    const ok = await savePromptOrder(row, next, input);
    if (!ok) {
      finished = false;
      input.focus();
      input.select();
    }
  };

  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') finish(true);
    if (event.key === 'Escape') finish(false);
  });
  input.addEventListener('blur', () => finish(true));
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error || new Error('图片读取失败'));
    reader.readAsDataURL(file);
  });
}

async function saveMapImage(row, file, statusEl) {
  if (!file || !file.type.startsWith('image/')) {
    statusEl.textContent = '仅支持图片';
    statusEl.classList.add('error');
    return;
  }
  statusEl.textContent = '保存中...';
  statusEl.classList.remove('error', 'saved');
  const dataUrl = await readFileAsDataUrl(file);
  const response = await fetch('/api/project-map-image', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      scene: normalizeDomainName(row.business_domain),
      order: getOrder(row),
      filename: file.name || '',
      data_url: dataUrl,
    }),
  });
  const payload = await response.json();
  if (!payload.ok) {
    statusEl.textContent = payload.error || '保存失败';
    statusEl.classList.add('error');
    return;
  }
  statusEl.textContent = `已保存 ${payload.filename}`;
  statusEl.classList.add('saved');
}

function mapInputCell(row) {
  const td = document.createElement('td');
  td.className = 'map-cell';

  const wrapper = document.createElement('div');
  wrapper.className = 'map-input-wrapper';

  const dropBox = document.createElement('div');
  dropBox.className = 'map-input-box';
  dropBox.tabIndex = 0;
  dropBox.textContent = '粘贴/拖入/选择图片';

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'image/*';
  fileInput.className = 'map-file-input';

  const status = document.createElement('span');
  status.className = 'map-save-status';

  const saveFirstFile = async (files) => {
    const file = Array.from(files || []).find((item) => item && item.type.startsWith('image/'));
    if (!file) {
      status.textContent = '未检测到图片';
      status.classList.add('error');
      return;
    }
    try {
      await saveMapImage(row, file, status);
    } catch (error) {
      status.textContent = error.message || '保存失败';
      status.classList.add('error');
    }
  };

  dropBox.addEventListener('click', (event) => {
    event.stopPropagation();
    fileInput.click();
  });
  dropBox.addEventListener('paste', async (event) => {
    event.preventDefault();
    event.stopPropagation();
    await saveFirstFile(event.clipboardData?.files);
  });
  dropBox.addEventListener('dragover', (event) => {
    event.preventDefault();
    dropBox.classList.add('dragging');
  });
  dropBox.addEventListener('dragleave', () => {
    dropBox.classList.remove('dragging');
  });
  dropBox.addEventListener('drop', async (event) => {
    event.preventDefault();
    event.stopPropagation();
    dropBox.classList.remove('dragging');
    await saveFirstFile(event.dataTransfer?.files);
  });
  fileInput.addEventListener('click', (event) => event.stopPropagation());
  fileInput.addEventListener('change', async () => {
    await saveFirstFile(fileInput.files);
    fileInput.value = '';
  });

  wrapper.append(dropBox, fileInput, status);
  td.appendChild(wrapper);
  return td;
}

function renderRows() {
  rowsEl.innerHTML = '';
  for (const [index, row] of filteredPrompts.entries()) {
    const tr = document.createElement('tr');
    tr.dataset.id = row.id;
    if (row.id === selectedPromptId) tr.classList.add('selected-row');
    if (isCompleted(row.id)) tr.classList.add('completed-row');
    const orderTd = document.createElement('td');
    orderTd.className = 'number-cell order-cell';
    
    const orderWrapper = document.createElement('div');
    orderWrapper.className = 'order-wrapper';
    
    const orderSpan = document.createElement('span');
    orderSpan.className = 'order-text';
    orderSpan.textContent = getOrder(row);
    
    const orderButtons = document.createElement('div');
    orderButtons.className = 'order-buttons';
    
    const copyOrder = actionButton('⧉', 'order-copy-button');
    copyOrder.addEventListener('click', async (event) => {
      event.stopPropagation();
      await copyText(getOrder(row), copyOrder);
    });
    const editOrder = actionButton('✎', 'order-button');
    editOrder.addEventListener('click', async (event) => {
      event.stopPropagation();
      beginOrderEdit(row, orderTd);
    });
    
    orderButtons.append(copyOrder, editOrder);
    orderWrapper.append(orderSpan, orderButtons);
    orderTd.appendChild(orderWrapper);

    tr.append(
      cell(row.name, 'name-cell'),
      orderTd,
      mapInputCell(row)
    );

    const actionTd = document.createElement('td');
    actionTd.className = 'action-cell';

    const doneButton = actionButton(isCompleted(row.id) ? '🔒' : '🔓', 'done-button');
    doneButton.title = '标记完成/未完成';
    doneButton.addEventListener('click', async (event) => {
      event.stopPropagation();
      await setCompleted(row.id, !isCompleted(row.id));
    });

    const copyButton = actionButton('⧉', 'mini-button');
    copyButton.title = '复制 Prompt';
    copyButton.addEventListener('click', async (event) => {
      event.stopPropagation();
      await copyText(row.prompt, copyButton);
    });

    const openButton = actionButton('🏷️', 'mini-button');
    openButton.title = '在 Trae 中打开项目目录';
    openButton.addEventListener('click', async (event) => {
      event.stopPropagation();
      const scene = normalizeDomainName(row.business_domain);
      const order = getOrder(row);
      try {
        const response = await fetch('/api/open-project-folder', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ scene, order }),
        });
        const payload = await response.json();
        if (!payload.ok) {
          console.error('打开项目目录失败:', payload.error);
        }
      } catch (error) {
        console.error('打开项目目录失败:', error);
      }
    });

    const mapsButton = actionButton('🖼', 'mini-button');
    mapsButton.title = '打开 maps 目录';
    mapsButton.addEventListener('click', async (event) => {
      event.stopPropagation();
      const scene = normalizeDomainName(row.business_domain);
      const order = getOrder(row);
      try {
        const response = await fetch('/api/open-project-maps-folder', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ scene, order }),
        });
        const payload = await response.json();
        if (!payload.ok) {
          console.error('打开 maps 目录失败:', payload.error);
        }
      } catch (error) {
        console.error('打开 maps 目录失败:', error);
      }
    });

    const windowsTraeButton = actionButton('🪟', 'mini-button');
    windowsTraeButton.title = '在 Windows 本机 Trae 中打开项目目录';
    windowsTraeButton.addEventListener('click', async (event) => {
      event.stopPropagation();
      const scene = normalizeDomainName(row.business_domain);
      const order = getOrder(row);
      try {
        const response = await fetch('http://127.0.0.1:8787/open-trae', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ scene, order }),
        });
        const payload = await response.json();
        if (!payload.ok) {
          console.error('Windows Trae 打开失败:', payload.error);
        }
      } catch (error) {
        console.error('Windows Trae helper 未启动或不可访问:', error);
      }
    });

    actionTd.append(doneButton, copyButton, openButton, mapsButton, windowsTraeButton);
    tr.appendChild(actionTd);

    tr.addEventListener('click', () => selectPrompt(row.id));
    rowsEl.appendChild(tr);
  }
}

function selectPrompt(promptId) {
  selectedPromptId = promptId;
  const prompt = prompts.find((item) => item.id === promptId);
  selectedParts = splitPrompt(prompt?.prompt || '未找到 Prompt，请先重新生成方案数据。');
  detailPanel.hidden = false;
  promptBackground.textContent = selectedParts.background;
  promptFeatures.textContent = selectedParts.features;
  promptDelivery.textContent = selectedParts.delivery;
  renderRows();
}

async function loadJson(path, fallback) {
  const response = await fetch(path, { cache: 'no-store' });
  if (!response.ok) return fallback;
  return response.json();
}

async function loadPromptState() {
  try {
    const response = await fetch('/api/prompt-state', { cache: 'no-store' });
    const payload = await response.json();
    promptState = payload.state || { completed: {} };
  } catch {
    promptState = { completed: {} };
  }
}


function renderSceneButtons() {
  const domains = uniqueSorted(prompts.map((prompt) => prompt.business_domain));
  sceneButtons.innerHTML = '';
  for (const domain of domains) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'scene-button';
    button.textContent = displayDomainName(domain);
    if (domainFilter.value === domain) button.classList.add('active');
    button.addEventListener('click', () => {
      domainFilter.value = domain;
      applyFilters();
      renderSceneButtons();
    });
    sceneButtons.appendChild(button);
  }
}

function bindFilters() {
  fillSelect(domainFilter, uniqueSorted(prompts.map((prompt) => prompt.business_domain)), '业务', displayDomainName);
  fillSelect(userFilter, uniqueSorted(prompts.map((prompt) => prompt.target_user)), '用户');
  fillSelect(platformFilter, uniqueSorted(prompts.map((prompt) => prompt.product_form)), '平台');
  fillSelect(scenarioFilter, uniqueSorted(prompts.map((prompt) => prompt.scenario)), '场景');
  for (const control of [domainFilter, userFilter, platformFilter, scenarioFilter, searchInput]) {
    control.addEventListener('input', applyFilters);
    control.addEventListener('change', applyFilters);
  }
}

function setSyncStatus(text, isError = false) {
  if (!syncGithubStatus) return;
  syncGithubStatus.textContent = text || '';
  syncGithubStatus.classList.toggle('error', Boolean(isError));
}

function setClaimStatus(text, isError = false) {
  if (!claimFeishuStatus) return;
  claimFeishuStatus.textContent = text || '';
  claimFeishuStatus.classList.toggle('error', Boolean(isError));
}

async function claimFeishuTasks() {
  if (!claimFeishuTasksButton || !feishuClaimCountInput) return;
  const count = Number.parseInt(feishuClaimCountInput.value, 10);
  if (!Number.isInteger(count) || count <= 0) {
    setClaimStatus('请输入大于 0 的数量', true);
    feishuClaimCountInput.focus();
    return;
  }

  claimFeishuTasksButton.disabled = true;
  setClaimStatus(`开始领取 ${count} 道题...`);
  try {
    const response = await fetch('/api/claim-feishu-tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ count }),
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || '领取失败');
    setClaimStatus(`完成：计划 ${payload.requested}，点击领取 ${payload.claimed}，翻页 ${payload.page_turns || 0}`);
  } catch (error) {
    setClaimStatus(`失败：${error.message}`, true);
  } finally {
    claimFeishuTasksButton.disabled = false;
  }
}

async function syncCompletedToGithub() {
  if (!syncGithubAllButton) return;
  syncGithubAllButton.disabled = true;
  setSyncStatus('同步中...');
  try {
    const response = await fetch('/api/sync-github-all', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || '同步失败');
    const synced = Number(payload.synced || 0);
    const skipped = Number(payload.skipped || 0);
    const failed = Number(payload.failed || 0);
    const firstFailed = (payload.results || []).find((item) => item && item.status === 'failed');
    const failureText = firstFailed ? `；首个失败：${firstFailed.order || firstFailed.prompt_id} ${firstFailed.reason || ''}` : '';
    setSyncStatus(`完成：同步 ${synced}，跳过 ${skipped}，失败 ${failed}${failureText}`);
  } catch (error) {
    setSyncStatus(`失败：${error.message}`, true);
  } finally {
    syncGithubAllButton.disabled = false;
  }
}

async function loadPromptFactory() {
  candidates = await loadJson('./data/generated/zero_to_one_candidates.json', []);
  prompts = await loadJson('./data/generated/generation_prompts.json', []);
  atoms = await loadJson('./data/normalized/product_atoms.json', []);
  prompts = prompts.map((prompt) => ({
    ...prompt,
    business_domain: normalizeDomainName(prompt.business_domain),
  }));
  candidates = candidates.map((candidate) => ({
    ...candidate,
    business_domain: normalizeDomainName(candidate.business_domain),
  }));
  atoms = atoms.map((atom) => ({
    ...atom,
    business_domain: normalizeDomainName(atom.business_domain),
  }));
  await loadPromptState();
  bindFilters();
  if ([...domainFilter.options].some((option) => option.value === 'shopping')) domainFilter.value = 'shopping';
  renderSceneButtons();
  applyFilters();
}


document.querySelectorAll('.part-copy').forEach((button) => {
  button.addEventListener('click', async () => {
    const part = button.dataset.part;
    await copyText(selectedParts[part] || '', button);
  });
});

function initDraggableDetailPanel() {
  if (!detailPanel) return;

  let dragState = null;

  const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

  detailPanel.addEventListener('pointerdown', (event) => {
    if (event.target.closest('button')) return;
    const rect = detailPanel.getBoundingClientRect();
    dragState = {
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top,
    };
    detailPanel.classList.add('dragging');
    detailPanel.setPointerCapture(event.pointerId);
  });

  detailPanel.addEventListener('pointermove', (event) => {
    if (!dragState) return;
    const rect = detailPanel.getBoundingClientRect();
    const left = clamp(event.clientX - dragState.offsetX, 0, window.innerWidth - rect.width);
    const top = clamp(event.clientY - dragState.offsetY, 0, window.innerHeight - rect.height);
    detailPanel.style.left = `${left}px`;
    detailPanel.style.top = `${top}px`;
    detailPanel.style.right = 'auto';
    detailPanel.style.bottom = 'auto';
    detailPanel.style.transform = 'none';
  });

  const stopDragging = (event) => {
    if (!dragState) return;
    dragState = null;
    detailPanel.classList.remove('dragging');
    if (detailPanel.hasPointerCapture(event.pointerId)) {
      detailPanel.releasePointerCapture(event.pointerId);
    }
  };

  detailPanel.addEventListener('pointerup', stopDragging);
  detailPanel.addEventListener('pointercancel', stopDragging);
}

initDraggableDetailPanel();

if (syncGithubAllButton) {
  syncGithubAllButton.addEventListener('click', syncCompletedToGithub);
}

if (claimFeishuTasksButton) {
  claimFeishuTasksButton.addEventListener('click', claimFeishuTasks);
}

loadPromptFactory().catch((error) => {
  rowsEl.innerHTML = `<tr><td colspan="3">数据加载失败：${error.message}</td></tr>`;
});
