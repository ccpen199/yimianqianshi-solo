#!/usr/bin/env python3
import json
import os
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DEFAULT_TRAE_EXE = r'D:\Users\Lenovo\AppData\Local\Programs\Trae CN\Trae CN.exe'
DEFAULT_PROJECTS_ROOT = r'D:\Users\Lenovo\Documents\trae_projects'


def scene_segment(value: str) -> str:
  text = str(value or '').strip().replace('\\', '').replace('/', '')
  return text or 'local_projects'


def project_folder(scene: str, order: str) -> str:
  projects_root = os.environ.get('TRAE_PROJECTS_ROOT', DEFAULT_PROJECTS_ROOT)
  local_projects_root = os.environ.get('TRAE_LOCAL_PROJECTS_ROOT', '')
  clean_scene = scene_segment(scene)
  clean_order = str(order or '').strip().replace('\\', '').replace('/', '')
  if not clean_order:
    raise RuntimeError('order is required')
  if clean_scene == 'local_projects' and local_projects_root:
    return os.path.join(local_projects_root, clean_order)
  return os.path.join(projects_root, clean_scene, clean_order)


class Handler(BaseHTTPRequestHandler):
  def _json(self, status: int, payload: dict):
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    self.send_response(status)
    self.send_header('Access-Control-Allow-Origin', '*')
    self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
    self.send_header('Access-Control-Allow-Headers', 'Content-Type')
    self.send_header('Content-Type', 'application/json; charset=utf-8')
    self.send_header('Content-Length', str(len(body)))
    self.end_headers()
    self.wfile.write(body)

  def do_OPTIONS(self):
    self._json(200, {'ok': True})

  def do_POST(self):
    if self.path != '/open-trae':
      self._json(404, {'ok': False, 'error': 'not found'})
      return
    try:
      length = int(self.headers.get('Content-Length', '0') or '0')
      payload = json.loads(self.rfile.read(length).decode('utf-8') or '{}')
      scene = str(payload.get('scene') or 'local_projects')
      order = str(payload.get('order') or '')
      trae_exe = os.environ.get('TRAE_EXE', DEFAULT_TRAE_EXE)
      folder = project_folder(scene, order)
      if not os.path.exists(trae_exe):
        self._json(500, {'ok': False, 'error': f'Trae not found: {trae_exe}'})
        return
      if not os.path.isdir(folder):
        self._json(404, {'ok': False, 'error': f'project folder not found: {folder}'})
        return
      subprocess.Popen([trae_exe, folder], close_fds=True)
      self._json(200, {'ok': True, 'folder': folder, 'trae': trae_exe})
    except Exception as err:
      self._json(500, {'ok': False, 'error': str(err)})

  def log_message(self, fmt, *args):
    print(fmt % args)


def main():
  port = int(os.environ.get('TRAE_HELPER_PORT', '8787'))
  server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
  print(f'Windows Trae helper started at http://127.0.0.1:{port}')
  print(f'TRAE_EXE={os.environ.get("TRAE_EXE", DEFAULT_TRAE_EXE)}')
  print(f'TRAE_PROJECTS_ROOT={os.environ.get("TRAE_PROJECTS_ROOT", DEFAULT_PROJECTS_ROOT)}')
  if os.environ.get('TRAE_LOCAL_PROJECTS_ROOT'):
    print(f'TRAE_LOCAL_PROJECTS_ROOT={os.environ["TRAE_LOCAL_PROJECTS_ROOT"]}')
  server.serve_forever()


if __name__ == '__main__':
  main()
