@echo off
setlocal

set "TRAE_EXE=D:\Users\Lenovo\AppData\Local\Programs\Trae CN\Trae CN.exe"
set "TRAE_PROJECTS_ROOT=D:\Users\Lenovo\Documents\trae_projects"
rem 如果 Windows 上项目根目录就是 local_projects，请取消下一行注释并改成真实路径：
rem set "TRAE_LOCAL_PROJECTS_ROOT=D:\Users\Lenovo\Documents\trae_projects\local_projects"
set "TRAE_HELPER_PORT=8787"

cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_windows_trae_helper.ps1"

pause
