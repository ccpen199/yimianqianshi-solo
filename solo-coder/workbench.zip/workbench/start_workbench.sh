#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
START_PORT="${1:-8090}"
PID_FILE="${ROOT_DIR}/.workbench.pid"
URL_FILE="${ROOT_DIR}/.workbench.url"
RUNNER="${ROOT_DIR}/.run_workbench_server.command"
LOG_FILE="${ROOT_DIR}/.workbench.log"
PLIST_FILE="${HOME}/Library/LaunchAgents/com.yimianqianshi.workbench.plist"
LAUNCH_LABEL="com.yimianqianshi.workbench"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 未安装，无法启动服务。"
  exit 1
fi

find_free_port() {
  local port="$1"
  local tries=0
  while [ "${tries}" -lt 50 ]; do
    if ! lsof -tiTCP:"${port}" -sTCP:LISTEN >/dev/null 2>&1; then
      echo "${port}"
      return 0
    fi
    port=$((port + 1))
    tries=$((tries + 1))
  done
  return 1
}

health_ok() {
  curl -fsS "http://127.0.0.1:${1}/api/health" >/dev/null 2>&1
}

if [ -f "${URL_FILE}" ]; then
  EXISTING_URL="$(cat "${URL_FILE}")"
  EXISTING_PORT="$(printf '%s' "${EXISTING_URL}" | sed -E 's#.*:([0-9]+)/.*#\1#')"
  if [ -n "${EXISTING_PORT}" ] && health_ok "${EXISTING_PORT}"; then
    open "${EXISTING_URL}" >/dev/null 2>&1 || true
    echo "Workbench 已在运行"
    echo "URL: ${EXISTING_URL}"
    exit 0
  fi
fi

PORT="$(find_free_port "${START_PORT}")" || {
  echo "未找到可用端口。"
  exit 1
}
URL="http://127.0.0.1:${PORT}/index.html"

echo "${URL}" > "${URL_FILE}"
rm -f "${RUNNER}"

if command -v launchctl >/dev/null 2>&1; then
  mkdir -p "$(dirname "${PLIST_FILE}")"
  cat > "${PLIST_FILE}" <<PLIST_EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${LAUNCH_LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>$(command -v python3)</string>
    <string>-u</string>
    <string>${ROOT_DIR}/serve_workbench.py</string>
    <string>${PORT}</string>
  </array>
  <key>WorkingDirectory</key>
  <string>${ROOT_DIR}</string>
  <key>StandardOutPath</key>
  <string>${LOG_FILE}</string>
  <key>StandardErrorPath</key>
  <string>${LOG_FILE}</string>
  <key>RunAtLoad</key>
  <true/>
</dict>
</plist>
PLIST_EOF
  launchctl bootout "gui/$(id -u)" "${PLIST_FILE}" >/dev/null 2>&1 || true
  launchctl bootstrap "gui/$(id -u)" "${PLIST_FILE}"
  launchctl kickstart -k "gui/$(id -u)/${LAUNCH_LABEL}" >/dev/null 2>&1 || true
else
  cd "${ROOT_DIR}"
  nohup python3 -u serve_workbench.py "${PORT}" > "${LOG_FILE}" 2>&1 < /dev/null &
  echo "$!" > "${PID_FILE}"
  cd - >/dev/null
fi

for _ in {1..50}; do
  if health_ok "${PORT}"; then
    PID="$(lsof -tiTCP:"${PORT}" -sTCP:LISTEN | head -n 1 || cat "${PID_FILE}" 2>/dev/null || true)"
    [ -n "${PID}" ] && echo "${PID}" > "${PID_FILE}"
    open "${URL}" >/dev/null 2>&1 || true
    echo "Workbench 已启动"
    echo "URL: ${URL}"
    echo "PID: ${PID:-unknown}"
    exit 0
  fi
  sleep 0.2
done

echo "服务未能在预期时间内启动。可直接打开静态页："
echo "${ROOT_DIR}/index.html"
exit 1
